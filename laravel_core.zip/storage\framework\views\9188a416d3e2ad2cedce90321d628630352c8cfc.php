<?php $__env->startSection('title', __('Projects') . ' | ' . __('Hồ Thành Thiện')); ?>
<?php $__env->startSection('description', app()->getLocale() == 'vi' ? 'Khám phá danh sách các dự án, sản phẩm phần mềm và ứng dụng web hiện đại được phát triển bởi Hồ Thành Thiện.' : 'Explore a curated portfolio of modern web applications, open-source tools, and software projects developed by Ho Thanh Thien.'); ?>
<?php $__env->startSection('keywords', app()->getLocale() == 'vi' ? 'Dự án Hồ Thành Thiện, Portfolio Dự án, Web Apps, Laravel Projects, Vue.js Projects' : 'Ho Thanh Thien Projects, Software Portfolio, Laravel Web Apps, Vue.js React Applications'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .page-hero {
        padding: 5rem 0 3rem;
        text-align: center;
        background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(124,58,237,0.15) 0%, transparent 70%);
    }
    .page-hero h1 { font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900; margin-bottom: 0.75rem; letter-spacing: -0.02em; }
    .page-hero p { color: var(--text-secondary); font-size: 1.1rem; }

    .projects-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(min(100%, 300px), 1fr)); gap: 1.5rem; }

    .project-card {
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: 16px; overflow: hidden; display: flex; flex-direction: column;
        transition: all 0.3s ease;
    }
    .project-card:hover { border-color: rgba(99,102,241,0.4); transform: translateY(-6px); box-shadow: 0 25px 50px rgba(0,0,0,0.08); }

    .project-image {
        height: 200px; overflow: hidden;
        background: linear-gradient(135deg, rgba(124,58,237,0.2), rgba(6,182,212,0.2));
        display: flex; align-items: center; justify-content: center; position: relative;
    }
    .project-image img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s; }
    .project-card:hover .project-image img { transform: scale(1.05); }
    .project-placeholder { font-size: 3rem; opacity: 0.3; }

    .project-featured-badge {
        position: absolute; top: 0.75rem; right: 0.75rem;
        background: var(--gradient); color: white;
        padding: 0.2rem 0.65rem; border-radius: 6px; font-size: 0.75rem; font-weight: 700;
    }

    .project-body { padding: 1.25rem; flex: 1; display: flex; flex-direction: column; }
    .project-tags { display: flex; flex-wrap: wrap; gap: 0.4rem; margin-bottom: 0.75rem; }
    .project-title { font-size: 1.1rem; font-weight: 700; margin-bottom: 0.5rem; }
    .project-desc { color: var(--text-secondary); font-size: 0.88rem; line-height: 1.6; flex: 1; margin-bottom: 1.25rem; }
    .project-links { display: flex; gap: 0.5rem; flex-wrap: wrap; margin-top: auto; }
    .project-links .btn { flex: 1 1 calc(33.333% - 0.5rem); min-width: 80px; justify-content: center; font-size: 0.85rem; padding: 0.5rem 0.75rem; }

    .empty-state { text-align: center; padding: 4rem 2rem; color: var(--text-secondary); }
    .empty-state i { font-size: 4rem; margin-bottom: 1rem; opacity: 0.3; }

    @media (max-width: 768px) {
        .page-hero { padding: 3.5rem 0 2rem; }
        .page-hero h1 { font-size: clamp(1.8rem, 6vw, 2.5rem); }
        .page-hero p { font-size: 1rem; }
    }

    @media (max-width: 640px) {
        .projects-grid { grid-template-columns: 1fr; }
    }

    @media (max-width: 480px) {
        .page-hero { padding: 2.75rem 0 1.5rem; }
        .project-image { height: 180px; }
        .project-body { padding: 1.1rem; }
        .project-links .btn { min-width: 70px; flex: 1; }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="page-hero">
    <div class="container">
        <h1 class="reveal"><?php echo __('heading_my_projects'); ?></h1>
        <p class="reveal delay-1"><?php echo e(__("Things I've built and worked on")); ?></p>
    </div>
</section>

<section class="section" style="padding-top:2rem">
    <div class="container">
        <?php if($projects->count()): ?>
        <div class="projects-grid">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="project-card reveal delay-<?php echo e(($loop->index % 3) + 1); ?>">
                <div class="project-image">
                    <?php if($project->image): ?>
                        <img src="<?php echo e(asset('storage/' . $project->image)); ?>" alt="<?php echo e($project->title); ?>" loading="lazy" decoding="async" onerror="this.onerror=null; this.src='<?php echo e(asset('images/og-image.webp')); ?>';">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/og-image.webp')); ?>" alt="<?php echo e($project->title); ?> - Thumbnail" loading="lazy" decoding="async">
                    <?php endif; ?>
                    <?php if($project->featured): ?>
                        <span class="project-featured-badge">⭐ <?php echo e(__('Featured')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="project-body">
                    <div class="project-tags">
                        <?php $__currentLoopData = $project->technologies->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="tag"><?php echo e($tech->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="project-title"><?php echo e($project->title); ?></div>
                    <p class="project-desc"><?php echo e(Str::limit(preg_replace('/\s+/', ' ', $project->description), 140)); ?></p>
                    <div class="project-links">
                        <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-eye"></i> <?php echo e(__('Details')); ?>

                        </a>
                        <?php if($project->github_url): ?>
                        <a href="<?php echo e($project->github_url); ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm">
                            <i class="fab fa-github"></i> <?php echo e(__('Code')); ?>

                        </a>
                        <?php endif; ?>
                        <?php if($project->demo_url): ?>
                        <a href="<?php echo e($project->demo_url); ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm">
                            <i class="fas fa-external-link-alt"></i> <?php echo e(__('Demo')); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($projects->hasPages()): ?>
        <div class="pagination-wrap reveal delay-2">
            <?php $__currentLoopData = $projects->links()->elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($url); ?>" class="page-link <?php echo e($projects->currentPage() == $page ? 'active' : ''); ?>"><?php echo e($page); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php else: ?>
        <div class="empty-state reveal">
            <i class="fas fa-code"></i>
            <h3><?php echo e(__('No projects yet')); ?></h3>
            <p><?php echo e(__('Check back soon!')); ?></p>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\aworkspace\CV\resources\views/projects/index.blade.php ENDPATH**/ ?>
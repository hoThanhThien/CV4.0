@extends('layouts.admin')

@section('title', 'Lập lịch tự động — AI Blog Studio')

@section('content')
<div class="page-header">
    <div>
        <h1><i class="fas fa-clock" style="color:var(--accent)"></i> Lập lịch tạo & đăng bài tự động</h1>
        <p style="color:var(--text-muted); font-size:0.9rem; margin-top:0.25rem">
            Hệ thống tự động kích hoạt AI theo lịch trình, sinh bài viết và phân bổ lịch xuất bản theo giờ Việt Nam (Asia/Ho_Chi_Minh).
        </p>
    </div>
    <div style="display:flex; gap:0.5rem; flex-wrap:wrap">
        <form method="POST" action="{{ route('admin.ai.automations.trigger-due') }}" onsubmit="const b=this.querySelector('button'); b.disabled=true; b.innerHTML='<i class=\'fas fa-spinner fa-spin\'></i> Đang quét lịch...';">
            @csrf
            <button type="submit" class="btn btn-secondary" title="Kiểm tra và thực thi ngay các lịch đăng bài / automation đã đến giờ">
                <i class="fas fa-sync-alt"></i> Quét lịch đến hạn
            </button>
        </form>
        <a href="{{ route('admin.ai.automations.create') }}" class="btn btn-primary">
            <i class="fas fa-plus"></i> Tạo Automation mới
        </a>
    </div>
</div>

<div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Tên Automation</th>
                <th>Cấu hình nội dung</th>
                <th>Tần suất & Giờ chạy</th>
                <th>Lần chạy tới (Next Run)</th>
                <th>Chế độ xuất bản</th>
                <th>Bài/Lần</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            @forelse($automations as $auto)
                <tr>
                    <td style="color:var(--text-muted)">{{ $auto->id }}</td>
                    <td>
                        <div style="font-weight:700">{{ $auto->name }}</div>
                        <div style="font-size:0.75rem; color:var(--text-muted)">Múi giờ: {{ $auto->timezone }}</div>
                    </td>
                    <td>
                        <div style="font-weight:600">{{ $auto->contentConfig->name ?? '—' }}</div>
                        <div style="font-size:0.75rem; color:var(--text-muted)">
                            Model: <code>{{ $auto->contentConfig ? $auto->contentConfig->getEffectiveModel() : 'default' }}</code>
                        </div>
                    </td>
                    <td>
                        <div style="font-weight:600; text-transform:capitalize">
                            <i class="fas fa-calendar" style="color:var(--accent)"></i> {{ $auto->frequency }}
                        </div>
                        <div style="font-size:0.8rem; color:var(--text-muted)">
                            Lúc: <strong>{{ substr($auto->execution_time, 0, 5) }}</strong>
                            @if($auto->frequency === 'weekly')
                                (Thứ {{ ($auto->day_of_week === 0) ? 'CN' : ($auto->day_of_week + 1) }})
                            @elseif($auto->frequency === 'monthly')
                                (Ngày {{ $auto->day_of_month }})
                            @endif
                        </div>
                    </td>
                    <td>
                        @if($auto->next_run_at && $auto->is_active)
                            <div style="font-size:0.85rem; font-weight:700; color:var(--accent)">
                                {{ $auto->next_run_at->timezone('Asia/Ho_Chi_Minh')->format('d/m/Y H:i') }}
                            </div>
                            <small style="color:var(--text-muted)">{{ $auto->next_run_at->diffForHumans() }}</small>
                        @else
                            <span style="color:var(--text-muted); font-size:0.85rem">—</span>
                        @endif
                    </td>
                    <td>
                        @if($auto->publishing_mode === 'manual_approval')
                            <span class="badge badge-warning" title="Tạo bài lưu Pending Review để Admin duyệt"><i class="fas fa-user-check"></i> Manual Approval</span>
                        @elseif($auto->publishing_mode === 'auto_schedule')
                            <span class="badge badge-info" title="Tự động lên lịch đăng cách nhau theo khoảng thời gian"><i class="fas fa-calendar-alt"></i> Auto Schedule</span>
                        @else
                            <span class="badge badge-success" title="Tự động đăng bài ngay khi sinh"><i class="fas fa-bolt"></i> Auto Publish</span>
                        @endif
                    </td>
                    <td style="text-align:center; font-weight:700">
                        {{ $auto->articles_per_run }}
                    </td>
                    <td>
                        <form method="POST" action="{{ route('admin.ai.automations.toggle-active', $auto->id) }}">
                            @csrf
                            @if($auto->is_active)
                                <button type="submit" class="badge badge-success" style="border:none; cursor:pointer" title="Bấm để tạm dừng">
                                    <i class="fas fa-play"></i> Bật
                                </button>
                            @else
                                <button type="submit" class="badge badge-secondary" style="border:none; cursor:pointer" title="Bấm để kích hoạt">
                                    <i class="fas fa-pause"></i> Tắt
                                </button>
                            @endif
                        </form>
                    </td>
                    <td>
                        <div style="display:flex; gap:0.35rem; align-items:center">
                            <!-- Nút Run Now -->
                            <form method="POST" action="{{ route('admin.ai.automations.run-now', $auto->id) }}"
                                data-confirm-type="ai"
                                data-confirm-icon="fa-bolt"
                                data-confirm-title="Kích hoạt chạy ngay Automation?"
                                data-confirm="Hệ thống sẽ gọi AI tạo bài viết ngay theo lịch &quot;{{ $auto->name }}&quot; (mất khoảng 10–30 giây). Bạn có muốn bắt đầu?"
                                data-confirm-btn="<i class='fas fa-bolt'></i> Chạy ngay"
                                data-loading-title="AI đang chạy Automation..."
                                data-loading-desc="Đang kết nối Google Gemini AI để phân tích chủ đề và biên soạn bài viết chuẩn SEO. Vui lòng giữ nguyên cửa sổ này...">
                                @csrf
                                <button type="submit" class="btn btn-secondary btn-sm" style="color:var(--accent)" title="Chạy ngay lập tức">
                                    <i class="fas fa-bolt"></i> Chạy ngay
                                </button>
                            </form>

                            <a href="{{ route('admin.ai.automations.edit', $auto->id) }}" class="btn btn-secondary btn-sm" title="Sửa">
                                <i class="fas fa-edit"></i>
                            </a>

                            <form method="POST" action="{{ route('admin.ai.automations.destroy', $auto->id) }}"
                                data-confirm-type="danger"
                                data-confirm-title="Xóa lịch tự động?"
                                data-confirm="Bạn có chắc chắn muốn xóa lịch tự động &quot;{{ $auto->name }}&quot;? Thao tác này không thể hoàn tác.">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="Xóa">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="9" style="text-align:center; padding:3rem; color:var(--text-muted)">
                        <i class="fas fa-calendar-times" style="font-size:2.5rem; opacity:0.3; display:block; margin-bottom:0.75rem"></i>
                        Chưa có lịch tự động nào. Nhấn "Tạo Automation mới" để thiết lập lịch viết bài định kỳ!
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

<div style="margin-top:1.5rem; padding:1.25rem; background:var(--bg-card); border:1px solid var(--border); border-radius:12px; font-size:0.86rem; color:var(--text-muted); line-height:1.65">
    <div style="font-weight:700; color:var(--text); margin-bottom:0.35rem">
        <i class="fas fa-check-circle" style="color:var(--success)"></i> Cơ chế tự động chạy nền (Auto-Scheduler & Web-Cron)
    </div>
    <div>
        Hệ thống đã tích hợp sẵn <strong>Web-Cron tự động</strong> và endpoint kích hoạt lịch hẹn định kỳ. Để đảm bảo chính xác tới từng phút trên cPanel Hosting ngay cả khi ban đêm không có khách truy cập, bạn có thể thêm 1 dòng trong <strong>cPanel &rarr; Cron Jobs</strong> (chọn <em>Once Per Minute</em> <code>* * * * *</code>):
    </div>
    <code style="display:block; margin-top:0.5rem; padding:0.6rem 0.85rem; background:var(--bg); border:1px solid var(--border); border-radius:8px; color:var(--accent); word-break:break-all">curl -s "{{ route('cron.schedule-run') }}" >/dev/null 2>&1</code>
</div>
@endsection

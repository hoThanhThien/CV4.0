<?php $__env->startSection('title', 'Thêm Brochure / Giấy khen'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1>Thêm Brochure / Giấy khen mới</h1>
        <p style="color:var(--text-muted); font-size:0.9rem; margin-top:0.25rem">Tải lên file PDF (Brochure, CV chi tiết, đề tài...) hoặc ảnh chụp Giấy khen, Bằng cấp, Chứng chỉ.</p>
    </div>
    <a href="<?php echo e(route('admin.certificates.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Quay lại
    </a>
</div>

<form method="POST" action="<?php echo e(route('admin.certificates.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div style="display:grid; grid-template-columns:1fr 360px; gap:1.5rem; align-items:start">
        <!-- Main Form -->
        <div>
            <div class="form-card" style="margin-bottom:1.5rem">
                <h3 style="font-size:1.1rem; margin-bottom:1.25rem; display:flex; align-items:center; gap:0.5rem; color:var(--text)">
                    <i class="fas fa-info-circle" style="color:var(--primary)"></i> Thông tin tài liệu
                </h3>

                <div class="form-group">
                    <label class="form-label" for="title">Tiêu đề / Tên chứng chỉ, tài liệu <span style="color:#ef4444">*</span></label>
                    <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder="VD: Hồ sơ năng lực & Brochure 2026, Giấy khen Giải Nhì NCKH..." required>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-size:0.8rem; color:#ef4444"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem">
                    <div class="form-group">
                        <label class="form-label" for="category">Phân loại <span style="color:#ef4444">*</span></label>
                        <select id="category" name="category" class="form-control" required>
                            <option value="brochure" <?php echo e(old('category') == 'brochure' ? 'selected' : ''); ?>>📄 Brochure / Hồ sơ năng lực</option>
                            <option value="certificate" <?php echo e(old('category') == 'certificate' ? 'selected' : ''); ?>>📜 Giấy khen / Chứng chỉ</option>
                            <option value="degree" <?php echo e(old('category') == 'degree' ? 'selected' : ''); ?>>🎓 Bằng tốt nghiệp / Bằng cấp</option>
                            <option value="award" <?php echo e(old('category') == 'award' ? 'selected' : ''); ?>>🏆 Giải thưởng / Huy chương</option>
                            <option value="other" <?php echo e(old('category') == 'other' ? 'selected' : ''); ?>>📁 Tài liệu khác</option>
                        </select>
                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-size:0.8rem; color:#ef4444"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="issuer">Đơn vị cấp / Tổ chức</label>
                        <input type="text" id="issuer" name="issuer" class="form-control" value="<?php echo e(old('issuer')); ?>" placeholder="VD: ĐH Công nghiệp Hà Nội, HaUI, Cisco...">
                        <?php $__errorArgs = ['issuer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-size:0.8rem; color:#ef4444"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="issue_date">Thời gian / Ngày cấp</label>
                    <input type="text" id="issue_date" name="issue_date" class="form-control" value="<?php echo e(old('issue_date')); ?>" placeholder="VD: 2026, 06/2026, hoặc Năm 2024 - 2026">
                    <?php $__errorArgs = ['issue_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-size:0.8rem; color:#ef4444"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label class="form-label" for="description">Mô tả / Ghi chú chi tiết</label>
                    <textarea id="description" name="description" class="form-control" rows="5" placeholder="Mô tả nội dung tài liệu, thành tích đạt được, ý nghĩa hoặc thông số đề tài..."><?php echo e(old('description')); ?></textarea>
                    <span style="font-size:0.8rem; color:var(--text-muted); display:block; margin-top:0.35rem">
                        Hỗ trợ xuống dòng và các gạch đầu dòng để trình bày thông tin đẹp mắt trên website.
                    </span>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-size:0.8rem; color:#ef4444"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Sidebar / Files Upload -->
        <div>
            <!-- Main Document File -->
            <div class="form-card" style="margin-bottom:1.5rem">
                <h3 style="font-size:1.05rem; margin-bottom:1rem; display:flex; align-items:center; gap:0.5rem; color:var(--text)">
                    <i class="fas fa-file-upload" style="color:var(--primary)"></i> File tài liệu đính kèm <span style="color:#ef4444">*</span>
                </h3>

                <div class="form-group">
                    <label class="form-label" for="file">Chọn file PDF hoặc Hình ảnh</label>
                    <input type="file" id="file" name="file" class="form-control" accept=".pdf,image/jpeg,image/png,image/webp" required onchange="handleFileSelect(this)">
                    <span style="font-size:0.78rem; color:var(--text-muted); display:block; margin-top:0.35rem">
                        Hỗ trợ file: <strong>.PDF, .JPG, .PNG, .WEBP</strong> (tối đa 25MB).
                    </span>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-size:0.8rem; color:#ef4444"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <!-- Preview box -->
                    <div id="file-info-preview" style="display:none; margin-top:0.85rem; padding:0.75rem; border-radius:8px; background:rgba(99,102,241,0.08); border:1px dashed var(--primary); align-items:center; gap:0.75rem">
                        <div id="file-icon" style="font-size:1.8rem; color:var(--primary)"></div>
                        <div style="flex:1; min-width:0">
                            <div id="file-name" style="font-weight:600; font-size:0.88rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis"></div>
                            <div id="file-size" style="font-size:0.75rem; color:var(--text-muted)"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Thumbnail / Cover Image -->
            <div class="form-card" style="margin-bottom:1.5rem">
                <h3 style="font-size:1.05rem; margin-bottom:1rem; display:flex; align-items:center; gap:0.5rem; color:var(--text)">
                    <i class="fas fa-image" style="color:var(--primary)"></i> Ảnh bìa / Xem trước (Tùy chọn)
                </h3>

                <div class="form-group">
                    <label class="form-label" for="thumbnail">Ảnh thu nhỏ hiển thị bên ngoài</label>
                    <input type="file" id="thumbnail" name="thumbnail" class="form-control" accept="image/*" onchange="previewThumbnail(this)">
                    <span style="font-size:0.78rem; color:var(--text-muted); display:block; margin-top:0.35rem">
                        Nếu để trống đối với file PDF, hệ thống sẽ tự động dùng biểu tượng PDF tài liệu sang trọng.
                    </span>
                    <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="font-size:0.8rem; color:#ef4444"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div id="thumb-preview-wrap" style="display:none; margin-top:0.85rem">
                        <img id="thumb-preview" src="" alt="Thumbnail preview" style="width:100%; max-height:160px; object-fit:cover; border-radius:8px; border:1px solid var(--border)">
                    </div>
                </div>
            </div>

            <!-- Display Settings -->
            <div class="form-card" style="margin-bottom:1.5rem">
                <h3 style="font-size:1.05rem; margin-bottom:1rem; display:flex; align-items:center; gap:0.5rem; color:var(--text)">
                    <i class="fas fa-cog" style="color:var(--primary)"></i> Cài đặt hiển thị
                </h3>

                <div class="form-group">
                    <label class="form-label" for="order">Thứ tự ưu tiên hiển thị</label>
                    <input type="number" id="order" name="order" class="form-control" value="<?php echo e(old('order', 0)); ?>" min="0">
                    <span style="font-size:0.78rem; color:var(--text-muted)">Số nhỏ hơn sẽ đứng trước (0 là ưu tiên cao nhất).</span>
                </div>

                <div style="margin-top:1rem; padding:0.75rem; border-radius:8px; background:var(--bg-subtle, rgba(255,255,255,0.03)); border:1px solid var(--border)">
                    <label style="display:flex; align-items:center; gap:0.6rem; cursor:pointer; font-weight:500; font-size:0.9rem">
                        <input type="checkbox" name="featured" value="1" <?php echo e(old('featured', 1) ? 'checked' : ''); ?> style="width:18px; height:18px; accent-color:var(--primary)">
                        <span><i class="fas fa-star" style="color:#eab308"></i> Ghim nổi bật trang chủ</span>
                    </label>
                    <span style="font-size:0.78rem; color:var(--text-muted); display:block; margin-top:0.35rem; margin-left:1.75rem">
                        Tài liệu này sẽ xuất hiện trên trang chủ để nhà tuyển dụng/đối tác xem ngay.
                    </span>
                </div>

                <div style="margin-top:1.5rem">
                    <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center; padding:0.75rem">
                        <i class="fas fa-save"></i> Lưu tài liệu
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
function handleFileSelect(input) {
    const file = input.files[0];
    const preview = document.getElementById('file-info-preview');
    const icon = document.getElementById('file-icon');
    const name = document.getElementById('file-name');
    const size = document.getElementById('file-size');

    if (file) {
        preview.style.display = 'flex';
        name.textContent = file.name;
        size.textContent = (file.size / (1024 * 1024)).toFixed(2) + ' MB';

        if (file.name.toLowerCase().endsWith('.pdf') || file.type === 'application/pdf') {
            icon.className = 'fas fa-file-pdf';
            icon.style.color = '#ef4444';
        } else {
            icon.className = 'fas fa-file-image';
            icon.style.color = '#06b6d4';
        }
    } else {
        preview.style.display = 'none';
    }
}

function previewThumbnail(input) {
    const file = input.files[0];
    const wrap = document.getElementById('thumb-preview-wrap');
    const img = document.getElementById('thumb-preview');

    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            img.src = e.target.result;
            wrap.style.display = 'block';
        }
        reader.readAsDataURL(file);
    } else {
        wrap.style.display = 'none';
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\aworkspace\CV\resources\views/admin/certificates/create.blade.php ENDPATH**/ ?>
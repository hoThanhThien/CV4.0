<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AiProvider;
use App\Services\AI\AIProviderFactory;
use Illuminate\Http\Request;
use Throwable;

class AIProviderController extends Controller
{
    public function index()
    {
        $providers = AiProvider::latest()->get();
        return view('admin.ai.providers.index', compact('providers'));
    }

    public function create()
    {
        return view('admin.ai.providers.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'provider_type' => 'required|in:openai,gemini,deepseek,custom',
            'api_key' => 'required|string',
            'model' => 'required|string|max:100',
            'base_url' => 'nullable|url|max:255',
            'temperature' => 'required|numeric|between:0,2',
            'max_tokens' => 'required|integer|min:200|max:65536',
            'timeout' => 'required|integer|min:10|max:300',
            'is_active' => 'boolean',
            'is_default' => 'boolean',
        ]);

        $validated = $this->cleanProviderData($validated);

        $validated['is_active'] = $request->boolean('is_active', true);
        $validated['is_default'] = $request->boolean('is_default', false);

        if ($validated['is_default']) {
            AiProvider::where('is_default', true)->update(['is_default' => false]);
        }

        AiProvider::create($validated);

        return redirect()->route('admin.ai.providers.index')->with('success', 'Đã thêm nhà cung cấp AI thành công!');
    }

    public function edit($id)
    {
        $provider = AiProvider::findOrFail($id);
        return view('admin.ai.providers.edit', compact('provider'));
    }

    public function update(Request $request, $id)
    {
        $provider = AiProvider::findOrFail($id);

        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'provider_type' => 'required|in:openai,gemini,deepseek,custom',
            'api_key' => 'nullable|string', // Leave blank to keep existing
            'model' => 'required|string|max:100',
            'base_url' => 'nullable|url|max:255',
            'temperature' => 'required|numeric|between:0,2',
            'max_tokens' => 'required|integer|min:200|max:65536',
            'timeout' => 'required|integer|min:10|max:300',
            'is_active' => 'boolean',
            'is_default' => 'boolean',
        ]);

        $validated = $this->cleanProviderData($validated);

        $validated['is_active'] = $request->boolean('is_active', true);
        $validated['is_default'] = $request->boolean('is_default', false);

        // Keep old API key if not updated
        if (empty($validated['api_key'])) {
            unset($validated['api_key']);
        }

        if ($validated['is_default']) {
            AiProvider::where('id', '!=', $id)->where('is_default', true)->update(['is_default' => false]);
        }

        $provider->update($validated);

        return redirect()->route('admin.ai.providers.index')->with('success', 'Đã cập nhật nhà cung cấp AI!');
    }

    private function cleanProviderData(array $validated): array
    {
        $validated['name'] = trim($validated['name']);
        if (!empty($validated['api_key'])) {
            $validated['api_key'] = trim($validated['api_key']);
        }
        if (!empty($validated['base_url'])) {
            $validated['base_url'] = trim($validated['base_url']);
        }

        $type = $validated['provider_type'];
        $model = trim((string) ($validated['model'] ?? ''));

        if ($type === 'gemini') {
            $gemini = new \App\Services\AI\Providers\GeminiProvider();
            $normalized = $gemini->normalizeModel($model);
            if ($normalized === '' && !empty($validated['api_key'])) {
                $discovered = $gemini->discoverModels($validated['api_key'], $validated['base_url'] ?? null);
                $normalized = $discovered[0]['id'] ?? '';
            }
            $model = $normalized !== '' ? $normalized : $model;
        }

        $validated['model'] = $model;
        return $validated;
    }

    /**
     * Dynamically fetch available models from the selected AI Provider API using the supplied or saved API key.
     */
    public function fetchModels(Request $request)
    {
        $validated = $request->validate([
            'provider_type' => 'nullable|in:openai,gemini,deepseek,custom',
            'api_key' => 'nullable|string',
            'provider_id' => 'nullable|integer|exists:ai_providers,id',
            'base_url' => 'nullable|url|max:255',
            'capability' => 'nullable|in:text,image',
        ]);

        $apiKey = trim((string) ($validated['api_key'] ?? ''));
        $baseUrl = !empty($validated['base_url']) ? trim($validated['base_url']) : null;
        $type = $validated['provider_type'] ?? null;
        $capability = $validated['capability'] ?? 'text';

        $existing = null;
        if (!empty($validated['provider_id'])) {
            $existing = AiProvider::find($validated['provider_id']);
        } elseif ($apiKey === '' && $type === null) {
            $existing = AiProvider::active()->default()->first() ?? AiProvider::active()->first();
        }

        if ($existing) {
            if ($type === null) {
                $type = $existing->provider_type;
            }
            if ($apiKey === '' && $existing->canDecryptApiKey()) {
                $apiKey = trim((string) $existing->getDecryptedApiKey());
            }
            if ($baseUrl === null && !empty($existing->base_url)) {
                $baseUrl = $existing->base_url;
            }
        }

        if (empty($type) || $apiKey === '') {
            return response()->json([
                'success' => false,
                'message' => 'Vui lòng chọn AI Provider hoặc nhập API Key trước khi tải danh sách Model từ nhà cung cấp.',
                'models' => [],
            ], 422);
        }

        if ($type === 'gemini') {
            $gemini = new \App\Services\AI\Providers\GeminiProvider();
            $models = $capability === 'image'
                ? $gemini->discoverImageModels($apiKey, $baseUrl, true)
                : $gemini->discoverModels($apiKey, $baseUrl, true);
        } elseif ($type === 'deepseek') {
            $ds = new \App\Services\AI\Providers\DeepSeekProvider();
            $effectiveBase = $baseUrl ?: config('ai.providers.deepseek.base_url');
            $models = $capability === 'image'
                ? $ds->discoverImageModels($apiKey, $effectiveBase)
                : $ds->discoverModels($apiKey, $effectiveBase);
        } else {
            $oa = new \App\Services\AI\Providers\OpenAIProvider();
            $models = $capability === 'image'
                ? $oa->discoverImageModels($apiKey, $baseUrl)
                : $oa->discoverModels($apiKey, $baseUrl);
        }

        if (empty($models)) {
            $emptyMsg = $capability === 'image'
                ? 'Nhà cung cấp này không trả về model tạo ảnh riêng biệt nào trên /models (hệ thống vẫn hỗ trợ tự động thiết kế Thumbnail & Ảnh OG bằng AI).'
                : 'Không lấy được danh sách Model từ API (kiểm tra lại API Key hoặc Base URL).';

            return response()->json([
                'success' => false,
                'message' => $emptyMsg,
                'models' => [],
            ], 400);
        }

        return response()->json([
            'success' => true,
            'message' => 'Đã tải ' . count($models) . ' model khả dụng trực tiếp từ API.',
            'models' => $models,
        ]);
    }

    public function destroy($id)
    {
        $provider = AiProvider::findOrFail($id);
        $provider->delete();

        return redirect()->route('admin.ai.providers.index')->with('success', 'Đã xóa nhà cung cấp AI!');
    }

    public function testConnection($id)
    {
        $provider = AiProvider::findOrFail($id);

        try {
            $adapter = AIProviderFactory::make($provider);
            $result = $adapter->testConnection($provider);

            $provider->update([
                'last_tested_at' => now(),
                'connection_status' => $result['success'] ? 'connected' : 'failed',
                'last_error_message' => $result['success'] ? null : $result['message'],
            ]);

            if (request()->wantsJson()) {
                return response()->json($result);
            }

            if ($result['success']) {
                return back()->with('success', $result['message']);
            } else {
                return back()->with('error', $result['message']);
            }
        } catch (Throwable $e) {
            $provider->update([
                'last_tested_at' => now(),
                'connection_status' => 'failed',
                'last_error_message' => $e->getMessage(),
            ]);

            $msg = 'Lỗi kiểm tra kết nối: ' . $e->getMessage();
            if (request()->wantsJson()) {
                return response()->json(['success' => false, 'message' => $msg], 500);
            }

            return back()->with('error', $msg);
        }
    }

    public function setDefault($id)
    {
        AiProvider::where('is_default', true)->update(['is_default' => false]);
        $provider = AiProvider::findOrFail($id);
        $provider->update(['is_default' => true, 'is_active' => true]);

        return back()->with('success', "Đã đặt '{$provider->name}' làm nhà cung cấp mặc định!");
    }

    public function toggleActive($id)
    {
        $provider = AiProvider::findOrFail($id);
        $provider->update(['is_active' => !$provider->is_active]);

        $status = $provider->is_active ? 'Đã kích hoạt' : 'Đã tạm dừng';
        return back()->with('success', "{$status} nhà cung cấp '{$provider->name}'!");
    }
}

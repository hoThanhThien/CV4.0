<?php $__env->startSection('title', $post->title . ' | ' . __('Hồ Thành Thiện')); ?>
<?php $__env->startSection('description', $post->excerpt ? Str::limit(strip_tags($post->excerpt), 155) : Str::limit(strip_tags($post->content), 155)); ?>
<?php $__env->startSection('og_type', 'article'); ?>
<?php $__env->startSection('og_image', $post->image ? asset('storage/' . $post->image) : asset('images/og-image.webp')); ?>

<?php $__env->startSection('structured_data'); ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "<?php echo e(e($post->title)); ?>",
  "description": "<?php echo e(e($post->excerpt ? Str::limit(strip_tags($post->excerpt), 180) : Str::limit(strip_tags($post->content), 180))); ?>",
  "author": {
    "@type": "Person",
    "name": "Hồ Thành Thiện",
    "url": "<?php echo e(url('/')); ?>"
  },
  "publisher": {
    "@type": "Person",
    "name": "Hồ Thành Thiện",
    "url": "<?php echo e(url('/')); ?>"
  },
  "datePublished": "<?php echo e($post->published_at ? $post->published_at->toIso8601String() : $post->created_at->toIso8601String()); ?>",
  "dateModified": "<?php echo e($post->updated_at->toIso8601String()); ?>",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php echo e(url()->current()); ?>"
  }
  <?php if($post->image): ?>
  ,"image": "<?php echo e(asset('storage/' . $post->image)); ?>"
  <?php endif; ?>
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .post-hero {
        padding: 5rem 0 2rem;
        background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(124,58,237,0.15) 0%, transparent 70%);
    }
    .breadcrumb { color: var(--text-secondary); font-size: 0.85rem; margin-bottom: 2rem; word-break: break-word; }
    .breadcrumb a { color: var(--accent-light); text-decoration: none; }
    .breadcrumb a:hover { text-decoration: underline; }

    .post-layout { display: grid; grid-template-columns: 1fr 300px; gap: 3rem; align-items: start; }

    .post-title { font-size: clamp(1.8rem, 4.5vw, 3rem); font-weight: 900; line-height: 1.2; margin-bottom: 1.25rem; letter-spacing: -0.02em; word-break: break-word; }
    .post-meta { display: flex; align-items: center; gap: 1.5rem; color: var(--text-secondary); font-size: 0.88rem; margin-bottom: 2rem; flex-wrap: wrap; }
    .post-meta i { color: var(--accent-light); }

    .post-image {
        border-radius: 16px; overflow: hidden; margin-bottom: 2.5rem;
        border: 1px solid var(--border);
    }
    .post-image img { width: 100%; height: auto; display: block; object-fit: cover; }

    .post-content {
        color: var(--text-secondary); font-size: 1rem; line-height: 1.85;
        word-break: break-word; overflow-wrap: break-word;
    }
    .post-content img { max-width: 100%; height: auto; border-radius: 12px; margin: 1.5rem 0; }
    .post-content h2, .post-content h3 { color: var(--text-primary); margin: 2rem 0 0.75rem; font-weight: 700; word-break: break-word; }
    .post-content h2 { font-size: clamp(1.3rem, 3.5vw, 1.5rem); }
    .post-content h3 { font-size: clamp(1.1rem, 3vw, 1.2rem); }
    .post-content p { margin-bottom: 1.25rem; }
    .post-content a { color: var(--accent-light); word-break: break-all; }
    .post-content ul, .post-content ol { margin: 1rem 0 1.25rem 1.5rem; }
    .post-content li { margin-bottom: 0.4rem; }
    .post-content code {
        background: rgba(124,58,237,0.15); color: var(--accent-light);
        padding: 0.2rem 0.5rem; border-radius: 5px; font-family: 'JetBrains Mono', monospace; font-size: 0.85em;
        word-break: break-all;
    }
    .post-content pre {
        background: #f1f5f9; border: 1px solid var(--border);
        border-radius: 12px; padding: 1.25rem; margin: 1.5rem 0; overflow-x: auto;
        max-width: 100%; -webkit-overflow-scrolling: touch;
    }
    .post-content pre code { background: none; padding: 0; color: var(--text-primary); word-break: normal; }
    .post-content blockquote {
        border-left: 3px solid var(--accent); padding: 0.5rem 1.25rem; margin: 1.5rem 0;
        background: rgba(124,58,237,0.05); border-radius: 0 8px 8px 0;
        color: var(--text-secondary); font-style: italic;
    }
    .post-content table {
        display: block; width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch;
        border-collapse: collapse; margin: 1.5rem 0;
    }

    .post-sidebar .card { margin-bottom: 1rem; }
    .post-sidebar .card h4 { font-size: 0.82rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-secondary); margin-bottom: 0.75rem; }

    @media (max-width: 768px) {
        .post-hero { padding: 3rem 0 1.5rem; }
        .post-layout { grid-template-columns: 1fr; gap: 2rem; }
        .post-title { font-size: clamp(1.6rem, 5.5vw, 2.3rem); }
        .post-meta { gap: 1rem; margin-bottom: 1.5rem; font-size: 0.82rem; }
        .post-image { margin-bottom: 1.75rem; border-radius: 12px; }
    }

    @media (max-width: 480px) {
        .post-hero { padding: 2.25rem 0 1.25rem; }
        .post-content pre { padding: 0.85rem; font-size: 0.8rem; }
        .breadcrumb { margin-bottom: 1.25rem; font-size: 0.8rem; }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="post-hero">
    <div class="container">
        <div class="breadcrumb reveal-fade">
            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a> /
            <a href="<?php echo e(route('blog.index')); ?>"><?php echo e(__('Blog')); ?></a> /
            <span><?php echo e(Str::limit($post->title, 40)); ?></span>
        </div>
    </div>
</div>

<section class="section" style="padding-top:1rem">
    <div class="container">
        <div class="post-layout">
            <!-- Main -->
            <article class="reveal">
                <h1 class="post-title"><?php echo e($post->title); ?></h1>
                <div class="post-meta">
                    <?php if($post->published_at): ?>
                    <span><i class="fas fa-calendar-alt"></i> <?php echo e($post->published_at->format('F d, Y')); ?></span>
                    <?php endif; ?>
                    <span><i class="fas fa-clock"></i> <?php echo e(ceil(str_word_count(strip_tags($post->content)) / 200)); ?> <?php echo e(__('min read')); ?></span>
                </div>

                <?php if($post->image): ?>
                <div class="post-image">
                    <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->title); ?>" loading="lazy" decoding="async" onerror="this.onerror=null; this.src='<?php echo e(asset('images/og-image.webp')); ?>';">
                </div>
                <?php endif; ?>

                <div class="post-content">
                    <?php if($post->ai_generated || str_contains($post->content, '<p>') || str_contains($post->content, '<h2>')): ?>
                        <?php echo $post->content; ?>

                    <?php else: ?>
                        <?php echo nl2br(e($post->content)); ?>

                    <?php endif; ?>

                    <?php if(!empty($post->faq) && is_array($post->faq)): ?>
                        <div style="margin-top:2.5rem; padding-top:1.5rem; border-top:1px solid var(--border)">
                            <h3 style="font-size:1.3rem; margin-bottom:1rem; color:var(--text-primary)"><i class="fas fa-question-circle" style="color:var(--accent-light)"></i> <?php echo e(__('FAQ')); ?></h3>
                            <div style="display:flex; flex-direction:column; gap:0.75rem">
                                <?php $__currentLoopData = $post->faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:10px; padding:1rem">
                                        <div style="font-weight:700; color:var(--text-primary); margin-bottom:0.35rem"><?php echo e($faq['question'] ?? ''); ?></div>
                                        <div style="color:var(--text-secondary); font-size:0.95rem; line-height:1.6"><?php echo e($faq['answer'] ?? ''); ?></div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($post->sources) && is_array($post->sources)): ?>
                        <div style="margin-top:2rem; padding-top:1rem; border-top:1px solid var(--border); font-size:0.9rem">
                            <h4 style="color:var(--text-secondary); margin-bottom:0.5rem"><i class="fas fa-link"></i> <?php echo e(__('Sources & References')); ?>:</h4>
                            <ul style="margin-left:1.5rem">
                                <?php $__currentLoopData = $post->sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e($source['url'] ?? '#'); ?>" target="_blank" rel="noopener"><?php echo e($source['title'] ?? ($source['url'] ?? '')); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </article>

            <!-- Sidebar -->
            <aside class="post-sidebar reveal delay-1">
                <?php if($post->excerpt): ?>
                <div class="card">
                    <h4><i class="fas fa-align-left"></i> <?php echo e(__('Summary')); ?></h4>
                    <p style="color: var(--text-secondary); font-size: 0.9rem; line-height: 1.6"><?php echo e($post->excerpt); ?></p>
                </div>
                <?php endif; ?>

                <div class="card">
                    <h4><i class="fas fa-info-circle"></i> <?php echo e(__('Details')); ?></h4>
                    <?php if($post->published_at): ?>
                    <div style="color: var(--text-secondary); font-size: 0.88rem; margin-bottom: 0.5rem;">
                        <i class="fas fa-calendar" style="color: var(--accent-light); width:16px"></i>
                        <?php echo e(__('Published')); ?> <?php echo e($post->published_at->format('M d, Y')); ?>

                    </div>
                    <?php endif; ?>
                    <div style="color: var(--text-secondary); font-size: 0.88rem;">
                        <i class="fas fa-clock" style="color: var(--accent-light); width:16px"></i>
                        <?php echo e(ceil(str_word_count(strip_tags($post->content)) / 200)); ?> <?php echo e(__('min read')); ?>

                    </div>
                </div>

                <a href="<?php echo e(route('blog.index')); ?>" class="btn btn-outline" style="width:100%; justify-content:center">
                    <i class="fas fa-arrow-left"></i> <?php echo e(__('All Articles')); ?>

                </a>
            </aside>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\aworkspace\CV\resources\views/blog/show.blade.php ENDPATH**/ ?>
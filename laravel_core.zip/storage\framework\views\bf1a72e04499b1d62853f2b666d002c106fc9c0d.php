<?php $__env->startSection('title', $project->title . ' | ' . __('Hồ Thành Thiện')); ?>
<?php $__env->startSection('description', Str::limit(strip_tags($project->description), 155)); ?>
<?php $__env->startSection('og_type', 'article'); ?>
<?php $__env->startSection('og_image', $project->image ? asset('storage/' . $project->image) : asset('images/og-image.webp')); ?>

<?php $__env->startSection('structured_data'); ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "<?php echo e(e($project->title)); ?>",
  "description": "<?php echo e(e(Str::limit(strip_tags($project->description), 200))); ?>",
  "applicationCategory": "WebApplication",
  "operatingSystem": "All",
  "author": {
    "@type": "Person",
    "name": "Hồ Thành Thiện",
    "url": "<?php echo e(url('/')); ?>"
  }
  <?php if($project->image): ?>
  ,"image": "<?php echo e(asset('storage/' . $project->image)); ?>"
  <?php endif; ?>
  <?php if($project->demo_url): ?>
  ,"url": "<?php echo e($project->demo_url); ?>"
  <?php endif; ?>
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .project-hero {
        padding: 5rem 0 3rem;
        background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(124,58,237,0.15) 0%, transparent 70%);
    }
    .project-hero .breadcrumb {
        color: var(--text-secondary); font-size: 0.85rem; margin-bottom: 1.5rem; word-break: break-word;
    }
    .project-hero .breadcrumb a { color: var(--accent-light); text-decoration: none; }
    .project-hero .breadcrumb a:hover { text-decoration: underline; }

    .project-detail {
        display: grid; grid-template-columns: 1fr 350px; gap: 3rem; align-items: start;
    }

    .project-image-full {
        border-radius: 16px; overflow: hidden; margin-bottom: 2rem;
        border: 1px solid var(--border);
        background: linear-gradient(135deg, rgba(124,58,237,0.2), rgba(6,182,212,0.2));
        min-height: 280px; display: flex; align-items: center; justify-content: center;
    }
    .project-image-full img { width: 100%; height: auto; max-height: 480px; object-fit: cover; display: block; }
    .project-image-full .placeholder { font-size: 5rem; opacity: 0.3; }

    .project-title { font-size: clamp(1.8rem, 4.5vw, 2.8rem); font-weight: 900; margin-bottom: 1rem; letter-spacing: -0.02em; word-break: break-word; }
    .project-desc { color: var(--text-secondary); font-size: 1.05rem; line-height: 1.85; word-break: break-word; white-space: pre-line; }

    .project-sidebar .card { margin-bottom: 1.25rem; }
    .project-sidebar .card h4 { font-size: 0.85rem; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.75rem; }

    .tech-tags { display: flex; flex-wrap: wrap; gap: 0.5rem; }

    .project-meta-item {
        display: flex; align-items: center; gap: 0.6rem;
        padding: 0.6rem 0; border-bottom: 1px solid var(--border); font-size: 0.9rem; word-break: break-word;
    }
    .project-meta-item:last-child { border-bottom: none; }
    .project-meta-item i { color: var(--accent-light); width: 16px; text-align: center; flex-shrink: 0; }
    .project-meta-item a { color: var(--text-primary); text-decoration: none; word-break: break-all; }
    .project-meta-item a:hover { color: var(--accent); }

    @media (max-width: 768px) {
        .project-hero { padding: 3rem 0 1.5rem; }
        .project-detail { grid-template-columns: 1fr; gap: 2rem; }
        .project-image-full { min-height: auto; margin-bottom: 1.25rem; }
    }

    @media (max-width: 480px) {
        .project-hero { padding: 2.25rem 0 1.25rem; }
        .project-title { font-size: clamp(1.5rem, 6vw, 2rem); }
        .project-meta-item { font-size: 0.85rem; }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="project-hero">
    <div class="container">
        <div class="breadcrumb reveal-fade">
            <a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a> /
            <a href="<?php echo e(route('projects.index')); ?>"><?php echo e(__('Projects')); ?></a> /
            <span><?php echo e($project->title); ?></span>
        </div>
    </div>
</section>

<section class="section" style="padding-top:1rem">
    <div class="container">
        <div class="project-detail">
            <!-- Main Content -->
            <div class="reveal">
                <div class="project-image-full">
                    <?php if($project->image): ?>
                        <img src="<?php echo e(asset('storage/' . $project->image)); ?>" alt="<?php echo e($project->title); ?>" loading="lazy" decoding="async" onerror="this.onerror=null; this.src='<?php echo e(asset('images/og-image.webp')); ?>';">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/og-image.webp')); ?>" alt="<?php echo e($project->title); ?> - Thumbnail" loading="lazy" decoding="async">
                    <?php endif; ?>
                </div>

                <h1 class="project-title"><?php echo e($project->title); ?></h1>
                <div class="project-desc"><?php echo nl2br(e($project->description)); ?></div>
            </div>

            <!-- Sidebar -->
            <aside class="project-sidebar reveal delay-1">
                <?php if($project->technologies->count()): ?>
                <div class="card">
                    <h4><i class="fas fa-microchip"></i> <?php echo e(__('Technologies')); ?></h4>
                    <div class="tech-tags">
                        <?php $__currentLoopData = $project->technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="tag"><?php echo e($tech->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="card">
                    <h4><i class="fas fa-link"></i> <?php echo e(__('Links')); ?></h4>
                    <?php if($project->github_url): ?>
                    <div class="project-meta-item">
                        <i class="fab fa-github"></i>
                        <a href="<?php echo e($project->github_url); ?>" target="_blank" rel="noopener"><?php echo e(__('View on GitHub')); ?></a>
                    </div>
                    <?php endif; ?>
                    <?php if($project->demo_url): ?>
                    <div class="project-meta-item">
                        <i class="fas fa-external-link-alt"></i>
                        <a href="<?php echo e($project->demo_url); ?>" target="_blank" rel="noopener"><?php echo e(__('Live Demo')); ?></a>
                    </div>
                    <?php endif; ?>
                    <?php if(!$project->github_url && !$project->demo_url): ?>
                    <p style="color: var(--text-secondary); font-size: 0.9rem;"><?php echo e(__('No links available')); ?></p>
                    <?php endif; ?>
                </div>

                <?php if($project->featured): ?>
                <div class="card" style="background: rgba(124,58,237,0.1); border-color: rgba(124,58,237,0.3)">
                    <div style="display:flex; align-items:center; gap:0.5rem; color: var(--accent-light); font-weight:700;">
                        <i class="fas fa-star"></i> <?php echo e(__('Featured Project')); ?>

                    </div>
                </div>
                <?php endif; ?>

                <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-outline" style="width:100%; justify-content:center">
                    <i class="fas fa-arrow-left"></i> <?php echo e(__('Back to Projects')); ?>

                </a>
            </aside>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\aworkspace\CV\resources\views/projects/show.blade.php ENDPATH**/ ?>